# -*- coding: utf-8 -*-
#尊重开源项目，使用带上原作者
from lxml import etree
import asyncio
import aiohttp
import pandas as pd
from pathlib import Path

current_path = Path.cwd()
#写上你想爬取地区的链接
def get_url_list():
    url_list = []
   # 默认排序
    url = 'https://cq.lianjia.com/ershoufang/pg%d/'
    #江北区
    url_jiangbei = 'https://cq.lianjia.com/ershoufang/jiangbei/pg%d/'
    url_jiangbeinew = 'https://cq.lianjia.com/ershoufang/jiangbei/pg%dco32/'
    
    #渝北区
    url_yubei = 'https://cq.lianjia.com/ershoufang/yubei/pg%d/'
    url_yubeinew = 'https://cq.lianjia.com/ershoufang/yubei/pg%dco32/'
    #南岸区
    url_nanan = 'https://cq.lianjia.com/ershoufang/nanan/pg%d/'
    url_nanannew = 'https://cq.lianjia.com/ershoufang/nanan/pg%dco32/'
    #巴南区
    url_banan = 'https://cq.lianjia.com/ershoufang/banan/pg%d/'
    url_banannew = 'https://cq.lianjia.com/ershoufang/banan/pg%dco32/'
    #沙坪坝
    url_shapingba = 'https://cq.lianjia.com/ershoufang/shapingba/pg%d/'
    url_shapingbanew = 'https://cq.lianjia.com/ershoufang/shapingba/pg%dco32/'
    #九龙坡
    url_jiulongpo = 'https://cq.lianjia.com/ershoufang/jiulongpo/pg%d/'
    url_jiulongponew = 'https://cq.lianjia.com/ershoufang/jiulongpo/pg%dco32/'
    #渝中
    url_yuhong = 'https://cq.lianjia.com/ershoufang/yuhong/pg%d/'
    url_yuhongnew = 'https://cq.lianjia.com/ershoufang/yuhong/pg%dco32/'
    #大渡口
    url_dadukou = 'https://cq.lianjia.com/ershoufang/dadukou/pg%d/'
    url_dadukounew = 'https://cq.lianjia.com/ershoufang/dadukou/pg%dco32/'
    #江津
    url_jiangjing = 'https://cq.lianjia.com/ershoufang/jiangjing/pg%d/'
    url_jiangjingnew = 'https://cq.lianjia.com/ershoufang/jiangjing/pg%dco32/'
    #北碚
    url_beibei= 'https://cq.lianjia.com/ershoufang/beibei/pg%d/'
    url_beibeinew= 'https://cq.lianjia.com/ershoufang/beibei/pg%dco32/'
    #开州区
    url_kaizhouqu = 'https://cq.lianjia.com/ershoufang/kaizhouqu/pg%d/'
    url_kaizhouqunew = 'https://cq.lianjia.com/ershoufang/kaizhouqu/pg%dco32/'
    #巫山县
    url_wushanxian1 = 'https://cq.lianjia.com/ershoufang/wushanxian1/pg%d/'
    url_wushanxian1new = 'https://cq.lianjia.com/ershoufang/wushanxian1/pg%dco32/'
    #巫溪县
    url_wuxixian = 'https://cq.lianjia.com/ershoufang/wuxixian/pg%d/'
    url_wuxixiannew = 'https://cq.lianjia.com/ershoufang/wuxixian/pg%dco32/'
    #璧山
    url_bishan = 'https://cq.lianjia.com/ershoufang/bishan/pg%d/'
    url_bishannew = 'https://cq.lianjia.com/ershoufang/bishan/pg%dco32/'
    #长寿
    url_changshou1 = 'https://cq.lianjia.com/ershoufang/changshou1/pg%d/'
    url_changshou1new = 'https://cq.lianjia.com/ershoufang/changshou1/pg%dco32/'
    #最新发布
    url_new = 'https://cq.lianjia.com/ershoufang/pg%dco32/'
    #地铁线分类
    #1号线
    url_ditiefang1 = 'https://cq.lianjia.com/ditiefang/li99564937/pg%d/'
    url_ditiefangnew1 = 'https://cq.lianjia.com/ditiefang/li99564937/pg%dco32'
    #二号线
    url_ditiefang2 = 'https://cq.lianjia.com/ditiefang/li99565004/pg%d/'
    url_ditiefangnew2 = 'https://cq.lianjia.com/ditiefang/li99565004/pg%dco32/'

    #三号线
    url_ditiefang3 = 'https://cq.lianjia.com/ditiefang/li99565454/pg%d/'
    url_ditiefangnew3 = 'https://cq.lianjia.com/ditiefang/li99565454/pg%dco32/'

    #四号线
    url_ditiefang4 = 'https://cq.lianjia.com/ditiefang/li3620036937288401/pg%d/'
    url_ditiefangnew4 = 'https://cq.lianjia.com/ditiefang/li3620036937288401/pg%dco32/'
    
    #五号线
    url_ditiefang5 = 'https://cq.lianjia.com/ditiefang/li3620028000976146/pg%d/'
    url_ditiefangnew5 = 'https://cq.lianjia.com/ditiefang/li3620028000976146/pg%dco32/'
    
    #段轨道交通5号线南
    url_ditiefangnan = 'https://cq.lianjia.com/ditiefang/li36000012585788/pg%d/'
    url_ditiefangnannew = 'https://cq.lianjia.com/ditiefang/li36000012585788/pg%dco32/'
    #汪跳线
    url_ditiefang7 = 'https://cq.lianjia.com/ditiefang/li3620070702313997/pg%d/'
    url_ditiefangnew7 = 'https://cq.lianjia.com/ditiefang/li3620070702313997/pg%dco32/'
    #六号线
    url_ditiefang6 = 'https://cq.lianjia.com/ditiefang/li99565455/pg%d/'
    url_ditiefangnew6 = 'https://cq.lianjia.com/ditiefang/li99565455/pg%dco32/'
    #九号线
    url_ditiefang9 = 'https://cq.lianjia.com/ditiefang/li3620064164368963/pg%d/'
    url_ditiefangnew9 = 'https://cq.lianjia.com/ditiefang/li3620064164368963/pg%dco32/'
    #十号线
    url_ditiefang10 = 'https://cq.lianjia.com/ditiefang/li3620027972660258/pg%d/'
    url_ditiefangnew10 = 'https://cq.lianjia.com/ditiefang/li3620027972660258/pg%dco32/'
    #环线
    url_ditiefang11 = 'https://cq.lianjia.com/ditiefang/li3620038069956918/pg%d/'
    url_ditiefangnew11 = 'https://cq.lianjia.com/ditiefang/li3620038069956918/pg%dco32/'
    #国博线
    url_ditiefang12 = 'https://cq.lianjia.com/ditiefang/li99565456/pg%d/'
    url_ditiefangnew12 = 'https://cq.lianjia.com/ditiefang/li99565456/pg%dco32/'
    #自动翻页功能
    for i in range(1, 101):
        url_list.append(url%i)
        url_list.append(url_jiangbei%i)
        url_list.append(url_jiangbeinew%i)
        url_list.append(url_yubei%i)
        url_list.append(url_yubeinew%i)
        url_list.append(url_nanan%i)
        url_list.append(url_nanannew%i)
        url_list.append(url_banan%i)
        url_list.append(url_banannew%i)
        url_list.append(url_shapingba%i)
        url_list.append(url_shapingbanew%i)
        url_list.append(url_jiulongpo%i)
        url_list.append(url_jiulongpo%i)
        url_list.append(url_yuhong%i)
        url_list.append(url_yuhong%i)
        url_list.append(url_dadukou%i)
        url_list.append(url_dadukou%i)
        url_list.append(url_jiangjing%i)
        url_list.append(url_jiangjingnew%i)
        url_list.append(url_beibei%i)
        url_list.append(url_beibeinew%i)
        url_list.append(url_kaizhouqu%i)
        url_list.append(url_kaizhouqunew%i)
        url_list.append(url_wushanxian1%i)
        url_list.append(url_wushanxian1new%i)
        url_list.append(url_wuxixian%i)
        url_list.append(url_wuxixiannew%i)
        url_list.append(url_bishan%i)
        url_list.append(url_bishannew%i)
        url_list.append(url_changshou1%i)
        url_list.append(url_changshou1new%i)
        url_list.append(url_new%i)
        url_list.append(url_ditiefang1%i)
        url_list.append(url_ditiefangnew1%i)
        url_list.append(url_ditiefang2%i)
        url_list.append(url_ditiefangnew2%i)
        url_list.append(url_ditiefang3%i)
        url_list.append(url_ditiefangnew3%i)
        url_list.append(url_ditiefang4%i)
        url_list.append(url_ditiefangnew4%i)
        url_list.append(url_ditiefang5%i)
        url_list.append(url_ditiefangnew5%i)
        url_list.append(url_ditiefang6%i)
        url_list.append(url_ditiefangnew6%i)
        url_list.append(url_ditiefangnan%i)
        url_list.append(url_ditiefangnannew%i)
        url_list.append(url_ditiefang7%i)
        url_list.append(url_ditiefangnew7%i)
        url_list.append(url_ditiefang9%i)
        url_list.append(url_ditiefangnew9%i)
        url_list.append(url_ditiefang10%i)
        url_list.append(url_ditiefangnew10%i)
        url_list.append(url_ditiefang11%i)
        url_list.append(url_ditiefangnew11%i)
        url_list.append(url_ditiefang12%i)
        url_list.append(url_ditiefangnew12%i)
    return url_list



async def get_page(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36 QIHU 360EE',
    }
    async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False), trust_env=True) as session:
        while True:
            try:
                async with session.get(url=url, headers=headers, timeout=8) as response:
                    # 更改相应数据的编码格式
                    response.encoding = 'gbk'
                    # 遇到IO请求挂起当前任务，等IO操作完成执行之后的代码，当协程挂起时，事件循环可以去执行其他任务。
                    page_text = await response.text()
                    # 未成功获取数据时，更换ip继续请求
                    if response.status != 200:
                        continue
                    print(f"{url}succss!")
                    break
            except Exception as e:
                print(e)
                # 捕获异常，继续请求
                continue
    return get_detail_url(page_text)


def get_detail_url(page_text):
    tree = etree.HTML(page_text)

    li_list = tree.xpath('//*[@id="content"]/div[1]/ul/li')
    detail_url_list = []
    for li in li_list:
        detail_url_list.append(li.xpath('./div[1]/div[1]/a/@href')[0])

    df = pd.DataFrame({'detail_url': detail_url_list})
    header = False if Path.exists(Path(current_path, 'detail_page_url.csv')) else True
    df.to_csv(Path(current_path, 'detail_page_url.csv'), index=False, mode='a', header=header)


async def main(loop):
    # 获取url列表
    url_list = get_url_list()
    count = 0
    # 创建任务对象并添加到任务列表中
    for url in url_list:
        await get_page(url)
        count += 1
        print(count)
        if count % 100 == 0:
            print('已爬取3000条数据！休眠1分钟！'.format(count))
            await asyncio.sleep(60)
        else:
            continue


if __name__=='__main__':
    # 修改事件循环的策略
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    # 创建事件循环对象
    loop = asyncio.get_event_loop()
    # 将任务添加到事件循环中并运行循环直至完成
    loop.run_until_complete(main(loop))
    # 关闭事件循环对象
    loop.close()
