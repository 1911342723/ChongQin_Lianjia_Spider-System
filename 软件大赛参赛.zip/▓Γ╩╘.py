import os
import sys
from cefpython3 import cefpython as cef
import tkinter as tk
from tkinter import ttk

# 初始化CEFPython
sys.excepthook = cef.ExceptHook  # To shutdown all CEF processes on error
cef.Initialize()

# 创建Tkinter窗口
root = tk.Tk()
root.geometry('800x600')

# 使用CEFPython创建浏览器控件
browser_frame = ttk.Frame(root)
browser_frame.pack(fill=tk.BOTH, expand=tk.YES)

browser = cef.CreateBrowserSync(browser_frame, url="file:///path/to/your/pyecharts.html")
browser.SetClientHandler(FocusHandler())  # 可选，用于处理焦点事件等

# 启动Tkinter事件循环
root.mainloop()

# 关闭CEFPython
cef.Shutdown()